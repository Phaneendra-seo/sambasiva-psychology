# Sambasiva Website Design System
## Complete Development Guide for Antigravity

---

## **WEBSITE OVERVIEW**

### **Business Identity**
- **Name**: Dr. Sambasiva - Psychologist & Life Skills Trainer
- **Profession**: Clinical Psychologist, Counselor, Life Coach
- **Location**: Visakhapatnam (Vizag), Andhra Pradesh, India
- **Experience**: 6.5+ years, 2,000+ clients, 22,000+ students trained
- **Specialization**: Mental health counseling, relationship therapy, stress management, life skills training
- **Target Audience**: Individuals, couples, students, corporate clients seeking mental wellness

### **Core Message**
"Transform Your Mind, Transform Your Life" - Evidence-based, compassionate mental health services

---

## **PAGES ARCHITECTURE**

### **1. Homepage (homepage-new.html)**
**Purpose**: Main landing page with SEO optimization for "psychologist in Vizag"
**Sections**:
- Hero section with primary CTA
- Trust statistics bar
- Problem recognition section
- Services overview
- Why choose section
- Location & service areas
- Booking options
- Testimonials
- Blog preview
- Newsletter signup

### **2. About Page (about-new.html)**
**Purpose**: Build trust and establish credentials
**Sections**:
- Professional background
- Educational qualifications
- 4-step therapeutic approach
- Philosophy and methodology
- Awards and recognition
- Media features

### **3. Psychology Services (services-new.html)**
**Purpose**: Detail mental health services
**Services**:
- Relationship & Marriage Counseling
- Stress & Anxiety Therapy
- Depression Treatment
- Self-Esteem & Identity
- Family Therapy
- Crisis Support

### **4. Training Programs (training-new.html)**
**Purpose**: Corporate and educational training
**Programs**:
- Life Skills Training (WHO recommended)
- Soft Skills Development
- Personality Development
- Communication Skills
- Corporate Wellness Programs

### **5. Blog (blog-new.html)**
**Purpose**: Mental health education and SEO content
**Categories**: Mental Health, Relationships, Therapy, Personal Growth

### **6. Contact (contact-new.html)**
**Purpose**: Lead generation and appointments
**Features**: Contact form, consultation booking, location map

### **7. Awards Gallery (awards-gallery.html)**
**Purpose**: Showcase achievements and build credibility

### **8. SEO Landing Page (psychologist-vizag.html)**
**Purpose**: Dedicated SEO page targeting "psychologist in Vizag" keywords

---

## **COLOR SYSTEM**

### **Primary Palette - Ocean Teal (Trust & Healing)**
```css
--primary: #0D8B8B;          /* Main brand color */
--primary-light: #14A5A5;    /* Hover states */
--primary-dark: #076666;     /* Dark accents */
--primary-deeper: #054D4D;   /* Deep elements */
--primary-glow: rgba(13, 139, 139, 0.12);  /* Glow effects */
```

### **Secondary Palette - Forest Sage (Growth & Nature)**
```css
--secondary: #6B9B7A;        /* Supporting elements */
--secondary-light: #8BB89A;  /* Light variations */
--secondary-dark: #4F7A5C;   /* Dark variations */
```

### **Accent Palette - Sunrise Gold (Hope & Warmth)**
```css
--gold: #D4A24C;             /* CTAs, highlights */
--gold-light: #E8BE6E;       /* Light gold */
--gold-dark: #B8862F;        /* Dark gold */
```

### **Warm Accent - Sunset Coral (Compassion)**
```css
--coral: #E07A5F;            /* Relationships, warmth */
--coral-light: #EF9A85;      /* Light coral */
--coral-dark: #C45D44;       /* Dark coral */
```

### **Tertiary Palette - Mystic Lavender (Wisdom)**
```css
--tertiary: #8B7CB5;         /* Wisdom, clarity */
--tertiary-light: #A899CC;   /* Light lavender */
--tertiary-dark: #6B5A99;    /* Dark lavender */
```

### **Neutral Backgrounds**
```css
--cream: #FAF7F2;            /* Main background */
--cream-dark: #F3EDE4;       /* Section backgrounds */
--cream-deeper: #EBE4D8;     /* Darker sections */
--white: #FFFFFF;           /* Clean white */
```

### **Text Colors**
```css
--text-dark: #1E2A2A;        /* Headings */
--text-medium: #3A4848;      /* Subheadings */
--text-light: #526161;       /* Body text */
--text-muted: #707F7F;       /* Light text */
```

---

## **TYPOGRAPHY SYSTEM**

### **Font Families**
```css
--font-display: 'Outfit', sans-serif;  /* Headings */
--font-accent: 'Outfit', sans-serif;   /* Special text */
--font-body: 'Outfit', sans-serif;     /* Body text */
```

### **Font Sizes**
- **Display**: 3.5rem - 4rem (56px - 64px)
- **H1**: 2.5rem - 3rem (40px - 48px)
- **H2**: 2rem - 2.5rem (32px - 40px)
- **H3**: 1.5rem - 2rem (24px - 32px)
- **H4**: 1.25rem - 1.5rem (20px - 24px)
- **Body**: 1rem - 1.125rem (16px - 18px)
- **Small**: 0.875rem (14px)

---

## **BUTTON SYSTEM**

### **Primary Button (.btn-primary)**
```css
background: var(--primary);
color: white;
padding: 0.85rem 1.75rem;
border-radius: 100px;
font-weight: 600;
transition: all 0.3s ease;
box-shadow: 0 4px 20px rgba(30, 42, 42, 0.08);
```

**Hover State**:
```css
background: var(--gold);
transform: translateY(-5px) scale(1.05);
box-shadow: 0 15px 35px rgba(212, 162, 76, 0.4);
```

### **Secondary Button (.btn-secondary)**
```css
background: transparent;
color: var(--primary);
border: 2px solid var(--primary);
```

**Hover State**:
```css
background: var(--primary);
color: white;
transform: translateY(-3px) scale(1.02);
```

### **Gold Button (.btn-gold)**
```css
background: var(--gold);
color: white;
```

**Hover State**:
```css
background: var(--primary);
color: white;
```

### **Coral Button (.btn-coral)**
```css
background: var(--coral);
color: white;
```

**Hover State**:
```css
background: var(--tertiary);
color: white;
```

### **Button Sizes**
- **Small (.btn-sm)**: 0.65rem 1.25rem padding, 0.875rem font
- **Large (.btn-lg)**: 1.1rem 2.25rem padding, 1rem font

---

## **COMPONENT SYSTEM**

### **Navigation Bar**
```css
background: rgba(250, 247, 242, 0.95);
backdrop-filter: blur(20px);
border-bottom: 1px solid rgba(13, 139, 139, 0.1);
padding: 1rem 0;
position: sticky;
top: 0;
z-index: 1000;
```

### **Hero Section**
```css
background: linear-gradient(135deg, #FAF7F2 0%, #E8F5F5 50%, #F5F0FA 100%);
padding: 6rem 0;
position: relative;
overflow: hidden;
```

### **Service Cards**
```css
background: white;
border-radius: 24px;
padding: 2rem;
box-shadow: 0 8px 40px rgba(30, 42, 42, 0.08);
transition: all 0.4s ease;
border: 1px solid rgba(13, 139, 139, 0.1);
```

**Hover State**:
```css
transform: translateY(-12px);
box-shadow: 0 20px 60px rgba(30, 42, 42, 0.15);
border-color: var(--primary);
```

### **Testimonial Cards**
```css
background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
color: white;
border-radius: 20px;
padding: 2rem;
position: relative;
```

### **Statistics Counter**
```css
font-size: 3rem;
font-weight: 700;
color: var(--primary);
margin-bottom: 0.5rem;
```

---

## **LAYOUT SYSTEM**

### **Container**
```css
max-width: 1200px;
margin: 0 auto;
padding: 0 2rem;
```

### **Grid Systems**
- **2-column**: `grid-template-columns: 1fr 1fr`
- **3-column**: `grid-template-columns: repeat(3, 1fr)`
- **4-column**: `grid-template-columns: repeat(4, 1fr)`
- **Auto-fit**: `grid-template-columns: repeat(auto-fit, minmax(300px, 1fr))`

### **Spacing Scale**
```css
--space-xs: 0.25rem;   /* 4px */
--space-sm: 0.5rem;    /* 8px */
--space-md: 1rem;      /* 16px */
--space-lg: 1.5rem;    /* 24px */
--space-xl: 2rem;      /* 32px */
--space-2xl: 3rem;     /* 48px */
--space-3xl: 4rem;     /* 64px */
```

---

## **SHADOW SYSTEM**

```css
--shadow-sm: 0 2px 8px rgba(30, 42, 42, 0.06);
--shadow-md: 0 4px 20px rgba(30, 42, 42, 0.08);
--shadow-lg: 0 8px 40px rgba(30, 42, 42, 0.1);
--shadow-xl: 0 16px 60px rgba(30, 42, 42, 0.12);
--shadow-glow-primary: 0 8px 30px rgba(13, 139, 139, 0.25);
--shadow-glow-gold: 0 8px 30px rgba(212, 162, 76, 0.25);
```

---

## **ANIMATION SYSTEM**

### **Transitions**
```css
transition: all 0.3s ease;
transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
transition: opacity 0.6s ease;
```

### **Animations**
- **Fade In**: `fadeInUp 0.6s ease forwards`
- **Slide In**: `slideIn 0.4s ease`
- **Bounce**: `bounce 2s ease-in-out infinite`
- **Pulse**: `pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite`

### **Scroll Reveal**
```css
opacity: 0;
transform: translateY(30px);
transition: all 0.6s ease;
```

---

## **FORM SYSTEM**

### **Input Fields**
```css
background: white;
border: 2px solid rgba(13, 139, 139, 0.1);
border-radius: 12px;
padding: 1rem;
font-size: 1rem;
transition: all 0.3s ease;
```

### **Focus State**
```css
border-color: var(--primary);
box-shadow: 0 0 0 3px rgba(13, 139, 139, 0.1);
outline: none;
```

### **Newsletter Form**
```css
display: flex;
gap: 1rem;
max-width: 480px;
margin: 0 auto;
```

---

## **RESPONSIVE BREAKPOINTS**

```css
/* Mobile */
@media (max-width: 600px) {
  .container { padding: 0 1rem; }
  h1 { font-size: 2rem; }
  .service-card { padding: 1.5rem; }
}

/* Tablet */
@media (max-width: 900px) {
  .nav-links { display: none; }
  .mobile-toggle { display: block; }
  .services-grid { grid-template-columns: 1fr 1fr; }
}

/* Desktop */
@media (min-width: 1200px) {
  .container { max-width: 1200px; }
}
```

---

## **ICON SYSTEM**

### **Lucide Icons**
- **Primary**: `heart`, `brain`, `users`, `shield-check`
- **Secondary**: `phone`, `mail`, `map-pin`, `calendar`
- **Tertiary**: `star`, `award`, `check-circle`, `arrow-right`

### **Icon Sizing**
```css
.icon-sm { width: 16px; height: 16px; }
.icon-md { width: 20px; height: 20px; }
.icon-lg { width: 24px; height: 24px; }
.icon-xl { width: 32px; height: 32px; }
```

---

## **SPECIAL COMPONENTS**

### **WhatsApp Float Button**
```css
position: fixed;
bottom: 28px;
right: 28px;
width: 56px;
height: 56px;
background: #25D366;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
box-shadow: 0 4px 20px rgba(37, 211, 102, 0.4);
animation: wa-bounce 3s ease-in-out 2s infinite;
```

### **Trust Statistics Bar**
```css
background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
color: white;
padding: 2rem 0;
display: grid;
grid-template-columns: repeat(4, 1fr);
gap: 2rem;
```

### **Newsletter Section**
```css
background: linear-gradient(135deg, var(--primary) 0%, var(--tertiary) 100%);
color: white;
padding: 4rem 0;
text-align: center;
```

---

## **SEO OPTIMIZATION**

### **Meta Tags Structure**
```html
<title>Best Psychologist in Vizag | Counseling in Visakhapatnam | Therapy Services</title>
<meta name="description" content="Looking for a psychologist in Vizag? Get expert counseling in Visakhapatnam for anxiety, stress, and relationships. 6.5+ years experience. Book now.">
<meta name="keywords" content="psychologist in Vizag, counseling in Vizag, best psychologist in Visakhapatnam, therapy for anxiety in Vizag, relationship counselor Vizag, clinical psychologist Vizag, mental health counseling Vizag, online counseling in Vizag, stress management therapy Vizag, depression treatment Vizag, psychologist near me">
```

### **Structured Data**
```json
{
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "name": "Dr. Sambasiva - Best Psychologist in Vizag",
  "description": "Professional psychologist in Vizag providing expert counseling and therapy services for mental wellness.",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "MVP Colony",
    "addressLocality": "Visakhapatnam",
    "addressRegion": "Andhra Pradesh",
    "postalCode": "530017",
    "addressCountry": "IN"
  }
}
```

---

## **PERFORMANCE OPTIMIZATION**

### **Image Optimization**
- Use WebP format
- Lazy loading with `loading="lazy"`
- Responsive images with `srcset`

### **CSS Optimization**
- Minify CSS files
- Use CSS variables for consistency
- Implement critical CSS inline

### **JavaScript Optimization**
- Defer non-critical scripts
- Use intersection observers for animations
- Implement smooth scrolling behavior

---

## **ACCESSIBILITY FEATURES**

### **ARIA Labels**
```html
<button aria-label="Toggle mobile menu">
<a href="tel:+919876543210" aria-label="Call +91 98765 43210">
```

### **Focus States**
```css
:focus {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}
```

### **Semantic HTML5**
- Use `<nav>`, `<main>`, `<section>`, `<article>` appropriately
- Proper heading hierarchy (h1-h6)
- Alt text for all images

---

## **DEVELOPMENT GUIDELINES**

### **File Structure**
```
/
  index.html (homepage)
  about.html
  services.html
  training.html
  blog.html
  contact.html
  assets/
    css/
      premium-theme.css
    js/
      main.js
    images/
      (optimized images)
```

### **Naming Conventions**
- **Classes**: kebab-case (`.service-card`, `.btn-primary`)
- **IDs**: kebab-case (`#main-navigation`, #contact-form`)
- **Files**: kebab-case with descriptive names

### **Code Standards**
- Use semantic HTML5 elements
- Implement CSS custom properties
- Follow mobile-first responsive design
- Ensure cross-browser compatibility

---

## **CONTENT STRATEGY**

### **Tone of Voice**
- Professional yet compassionate
- Evidence-based approach
- Hope-focused and empowering
- Confidential and trustworthy

### **Key Messaging**
- "Transform Your Mind, Transform Your Life"
- "6.5+ years experience, 2,000+ clients helped"
- "100% confidential counseling sessions"
- "Evidence-based therapeutic approaches"

### **Call-to-Action Strategy**
- Primary: "Book Session"
- Secondary: "Learn More"
- Tertiary: "Contact Us"
- Emergency: "Get Help Now"

---

This design system provides a comprehensive foundation for building the Sambasiva website with consistent branding, optimal user experience, and strong SEO performance. All components are designed to work together harmoniously while maintaining the therapeutic, professional aesthetic appropriate for a mental health practice.
