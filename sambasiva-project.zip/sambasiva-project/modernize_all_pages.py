import re
import os

def get_base_components():
    # Read index-new.html to extract the new components
    with open('index-new.html', 'r', encoding='utf-8') as f:
        index_content = f.read()

    # Extract Navbar
    nav_match = re.search(r'<nav class="navbar" id="navbar">.*?</nav>', index_content, re.DOTALL)
    navbar_html = nav_match.group(0) if nav_match else ''

    # Extract Footer
    footer_match = re.search(r'<footer class="footer" id="footer">.*?</footer>', index_content, re.DOTALL)
    footer_html = footer_match.group(0) if footer_match else ''

    # Extract inline JS
    js_match = re.search(r'<script>(?!.*?<script>).*?</script>\s*(?=</body>)', index_content, re.DOTALL)
    js_html = js_match.group(0) if js_match else ''
    
    return navbar_html, footer_html, js_html

def fix_inner_page(target_file, navbar_html, footer_html, js_html):
    # Fix paths for the inner page (prepend ../ to root html files)
    html_pages = [
        'index-new.html', 'about-new.html', 'services-new.html', 
        'training-new.html', 'blog-new.html', 'awards-gallery.html', 'contact-new.html'
    ]

    def fix_paths(html_str):
        for page in html_pages:
            # Replace href="page.html" with href="../page.html"
            html_str = re.sub(f'href="{page}"', f'href="../{page}"', html_str)
        return html_str

    navbar_fixed = fix_paths(navbar_html)
    footer_fixed = fix_paths(footer_html)
    
    # Read target file
    with open(target_file, 'r', encoding='utf-8') as f:
        target_content = f.read()

    # Replace Navbar
    if navbar_fixed:
        target_content = re.sub(r'<nav class="navbar" id="navbar">.*?</nav>', navbar_fixed, target_content, flags=re.DOTALL)

    # Replace Footer
    if footer_fixed:
        target_content = re.sub(r'<footer class="footer" id="footer">.*?</footer>', footer_fixed, target_content, flags=re.DOTALL)

    # Replace JS
    target_content = re.sub(r'<script src="\.\./assets/js/main\.js"></script>\s*', '', target_content)
    target_content = re.sub(r'<script>.*?</script>\s*(?=</body>)', '', target_content, flags=re.DOTALL)
    target_content = target_content.replace('</body>', f'{js_html}\n</body>')

    with open(target_file, 'w', encoding='utf-8') as f:
        f.write(target_content)
    print(f'Updated {target_file}')

if __name__ == "__main__":
    nav, foot, js = get_base_components()
    
    # Process all service pages
    service_dir = 'services'
    if os.path.exists(service_dir):
        for file in os.listdir(service_dir):
            if file.endswith('.html'):
                fix_inner_page(os.path.join(service_dir, file), nav, foot, js)
                
    # Process all training pages
    training_dir = 'training'
    if os.path.exists(training_dir):
        for file in os.listdir(training_dir):
            if file.endswith('.html'):
                fix_inner_page(os.path.join(training_dir, file), nav, foot, js)
