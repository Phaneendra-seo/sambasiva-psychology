# Sambasiva Website Documentation

## Overview
Professional website for Sambasiva - psychologist & life skills trainer in Vizag, India.

## Key Info
- **Professional**: Sambasiva - Psychologist & Life Coach
- **Location**: Visakhapatnam, Andhra Pradesh, India
- **Experience**: 6.5+ years, 2,000+ clients, 22,000+ students trained
- **Contact**: hello@sambasiva.com | +91 98765 43210
- **Rating**: 4.9/5 client satisfaction

## Pages Structure
1. **Home** - Hero section, services overview, statistics, testimonials, blog preview
2. **About** - Professional background, philosophy, credentials, 4-step approach
3. **Psychology Services** - Relationship, marital, stress/anxiety, self-esteem, crisis, family therapy
4. **Training** - Life skills, soft skills, personality development, communication

## Design Features
### Color Scheme
- Primary Teal (#14A5A5) - Trust, healing
- Coral (#EF9A85) - Compassion, relationships
- Gold (#E8BE6E) - Hope, success
- Lavender (#A899CC) - Wisdom, clarity
- Sage Green (#8BB89A) - Growth, nature

### Layout Elements
- Hero sections with gradient backgrounds
- Color-coded service cards with icons
- Animated statistics counters
- Client testimonials with ratings
- Comprehensive footer with newsletter

### Interactive Features
- Mobile responsive with hamburger menu
- Scroll reveal animations
- Form validation
- FAQ accordions
- WhatsApp floating button

## Technical Details
- HTML5 semantic structure with SEO meta tags
- Custom CSS with Grid/Flexbox layouts
- Lucide icons integration
- Smooth animations and transitions
- Schema.org structured data

## Content Strategy
- Professional, compassionate tone
- Evidence-based approach messaging
- Key slogan: "Transform Your Mind, Transform Your Life"
- Primary CTA: "Book Session"
- Emphasis on confidentiality

## Professional Credentials
- Rehabilitation Council of India Certified
- Andhra University - Master's in Psychology
- CBT & NLP Certifications
- Multiple awards and media recognition

This website effectively positions Sambasiva as a credible mental health professional offering evidence-based counseling and life skills training to diverse audiences.
