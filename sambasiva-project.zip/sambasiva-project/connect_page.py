import re
import os

def connect_relationship_counselling():
    # 1. Update services-new.html
    with open('services-new.html', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Add Learn More button before Book Session in the Relationship Issues card
    old_cta = '<a href="contact-new.html" class="btn btn-coral btn-sm"><span>Book Session</span></a>'
    new_cta = '<div style="display: flex; gap: 0.75rem;"><a href="services/relationship-counselling.html" class="btn btn-secondary btn-sm" style="border-color: var(--coral); color: var(--coral);"><span>Learn More</span></a><a href="contact-new.html" class="btn btn-coral btn-sm"><span>Book Session</span></a></div>'
    
    # We want to target only the first occurrence (Relationship Issues)
    content = content.replace(old_cta, new_cta, 1)
    
    with open('services-new.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print('Updated services-new.html with Relationship Counselling link')

    # 2. Update global footer links in all *new.html files
    files = [f for f in os.listdir('.') if f.endswith('-new.html')]
    for file in files:
        with open(file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # In footer, update "Relationship Counselling" link
        # It currently might look like href="services-new.html">Relationship Counselling
        content = re.sub(r'href="(../)?services-new.html">Relationship Counselling', 'href="\\1services/relationship-counselling.html">Relationship Counselling', content)
        
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
    print('Updated global footer links for Relationship Counselling')

if __name__ == "__main__":
    connect_relationship_counselling()
