# SAMBASIVA PSYCHOLOGY WEBSITE - COMPLETE DEVELOPMENT SPECIFICATION
## Ultra-Detailed Implementation Guide for Issue-Free Development

---

## **PROJECT OVERVIEW & REQUIREMENTS**

### **Business Context**
- **Client**: Dr. Sambasiva - Clinical Psychologist & Life Skills Trainer
- **Location**: Visakhapatnam (Vizag), Andhra Pradesh, India
- **Target Market**: Local Vizag residents + Pan-India online clients
- **Primary Goal**: Convert website visitors into counseling clients
- **Secondary Goal**: Establish authority in mental health space
- **Tertiary Goal**: Generate training program leads

### **Technical Requirements**
- **Performance**: <3 seconds load time, 90+ PageSpeed Insights
- **SEO**: #1 ranking for "psychologist in Vizag" within 6 months
- **Accessibility**: WCAG 2.1 AA compliance
- **Browser Support**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
- **Mobile**: First responsive design, iOS 12+, Android 8+
- **Security**: HTTPS, form validation, data protection

---

## **COMPLETE FILE STRUCTURE**

```
sambasiva-website/
|
|-- index.html                    # Homepage (SEO-optimized)
|-- about.html                    # About page
|-- services.html                 # Psychology services
|-- training.html                 # Training programs
|-- blog.html                     # Blog listing
|-- contact.html                  # Contact & booking
|-- awards.html                   # Awards gallery
|-- psychologist-vizag.html       # SEO landing page
|
|-- assets/
|   |-- css/
|   |   |-- reset.css            # CSS reset
|   |   |-- variables.css        # CSS custom properties
|   |   |-- typography.css       # Typography system
|   |   |-- layout.css           # Layout utilities
|   |   |-- components.css       # UI components
|   |   |-- pages.css            # Page-specific styles
|   |   |-- responsive.css       # Media queries
|   |   |-- animations.css       # Animations & transitions
|   |   |-- utilities.css        # Utility classes
|   |   |-- print.css            # Print styles
|   |   `-- main.css             # Main CSS file (imports all)
|   |
|   |-- js/
|   |   |-- main.js              # Main JavaScript file
|   |   |-- navigation.js        # Navigation functionality
|   |   |-- animations.js        # Scroll animations
|   |   |-- forms.js             # Form validation
|   |   |-- counters.js          # Statistics counters
|   |   |-- mobile-menu.js       # Mobile menu
|   |   `-- utils.js             # Utility functions
|   |
|   |-- images/
|   |   |-- hero/                # Hero section images
|   |   |-- services/            # Service icons & images
|   |   |-- about/               # About page images
|   |   |-- testimonials/        # Client photos
|   |   |-- awards/              # Award images
|   |   |-- blog/                # Blog post images
|   |   |-- ui/                  # UI elements (icons, buttons)
|   |   `-- favicon/             # Favicon files
|   |
|   |-- fonts/                   # Font files (if self-hosted)
|   `-- videos/                  # Video content
|
|-- blog/
|   |-- building-healthy-relationships.html
|   |-- building-self-confidence.html
|   |-- mental-health-workplace.html
|   |-- mindfulness-daily-life.html
|   `-- [other blog posts]
|
|-- services/
|   |-- crisis-support.html
|   |-- family-therapy.html
|   |-- relationship-counselling.html
|   |-- self-esteem.html
|   `-- [other service pages]
|
|-- training/
|   |-- corporate-training.html
|   |-- life-skills.html
|   |-- student-development.html
|   `-- workshops.html
|
|-- components/
|   |-- header.html              # Header component
|   |-- footer.html              # Footer component
|   |-- navigation.html          # Navigation markup
|   `-- newsletter.html         # Newsletter component
|
`-- docs/
    |-- development-guide.md     # This document
    |-- style-guide.md          # Style guidelines
    `-- seo-guide.md            # SEO specifications
```

---

## **COMPLETE CSS ARCHITECTURE**

### **1. reset.css - CSS Reset**
```css
/* Modern CSS Reset */
*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  line-height: 1.15;
  -webkit-text-size-adjust: 100%;
  scroll-behavior: smooth;
}

body {
  margin: 0;
  font-family: var(--font-body);
  font-size: 1rem;
  line-height: 1.6;
  color: var(--text-medium);
  background-color: var(--cream);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

img, picture, video, canvas, svg {
  display: block;
  max-width: 100%;
}

input, button, textarea, select {
  font: inherit;
}

p, h1, h2, h3, h4, h5, h6 {
  overflow-wrap: break-word;
}

#root {
  isolation: isolate;
}
```

### **2. variables.css - CSS Custom Properties**
```css
:root {
  /* ===== COLOR SYSTEM ===== */
  /* Primary - Ocean Teal */
  --color-primary-50: #f0fdfa;
  --color-primary-100: #ccfbf1;
  --color-primary-200: #99f6e4;
  --color-primary-300: #5eead4;
  --color-primary-400: #2dd4bf;
  --color-primary-500: #14b8a6;  /* Main primary */
  --color-primary-600: #0d9488;
  --color-primary-700: #0f766e;
  --color-primary-800: #115e59;
  --color-primary-900: #134e4a;
  
  /* Secondary - Forest Sage */
  --color-secondary-50: #f0fdf4;
  --color-secondary-100: #dcfce7;
  --color-secondary-200: #bbf7d0;
  --color-secondary-300: #86efac;
  --color-secondary-400: #4ade80;
  --color-secondary-500: #22c55e;  /* Main secondary */
  --color-secondary-600: #16a34a;
  --color-secondary-700: #15803d;
  --color-secondary-800: #166534;
  --color-secondary-900: #14532d;
  
  /* Accent - Sunrise Gold */
  --color-accent-50: #fffbeb;
  --color-accent-100: #fef3c7;
  --color-accent-200: #fde68a;
  --color-accent-300: #fcd34d;
  --color-accent-400: #fbbf24;
  --color-accent-500: #f59e0b;  /* Main accent */
  --color-accent-600: #d97706;
  --color-accent-700: #b45309;
  --color-accent-800: #92400e;
  --color-accent-900: #78350f;
  
  /* Warm - Sunset Coral */
  --color-warm-50: #fff1f2;
  --color-warm-100: #ffe4e6;
  --color-warm-200: #fecdd3;
  --color-warm-300: #fda4af;
  --color-warm-400: #fb7185;
  --color-warm-500: #f43f5e;  /* Main warm */
  --color-warm-600: #e11d48;
  --color-warm-700: #be123c;
  --color-warm-800: #9f1239;
  --color-warm-900: #881337;
  
  /* Cool - Mystic Lavender */
  --color-cool-50: #faf5ff;
  --color-cool-100: #f3e8ff;
  --color-cool-200: #e9d5ff;
  --color-cool-300: #d8b4fe;
  --color-cool-400: #c084fc;
  --color-cool-500: #a855f7;  /* Main cool */
  --color-cool-600: #9333ea;
  --color-cool-700: #7c3aed;
  --color-cool-800: #6b21a8;
  --color-cool-900: #581c87;
  
  /* Neutral Grays */
  --color-gray-50: #fafafa;
  --color-gray-100: #f5f5f5;
  --color-gray-200: #e5e5e5;
  --color-gray-300: #d4d4d4;
  --color-gray-400: #a3a3a3;
  --color-gray-500: #737373;
  --color-gray-600: #525252;
  --color-gray-700: #404040;
  --color-gray-800: #262626;
  --color-gray-900: #171717;
  
  /* Semantic Colors */
  --color-success: var(--color-secondary-500);
  --color-warning: var(--color-accent-500);
  --color-error: var(--color-warm-500);
  --color-info: var(--color-cool-500);
  
  /* Background Colors */
  --color-bg-primary: #ffffff;
  --color-bg-secondary: var(--color-gray-50);
  --color-bg-tertiary: var(--cream);
  --color-bg-inverse: var(--color-gray-900);
  
  /* Text Colors */
  --color-text-primary: var(--color-gray-900);
  --color-text-secondary: var(--color-gray-700);
  --color-text-tertiary: var(--color-gray-500);
  --color-text-inverse: var(--color-gray-50);
  
  /* Border Colors */
  --color-border-primary: var(--color-gray-200);
  --color-border-secondary: var(--color-gray-300);
  --color-border-focus: var(--color-primary-500);
  
  /* ===== TYPOGRAPHY SYSTEM ===== */
  /* Font Families */
  --font-family-sans: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --font-family-serif: 'Playfair Display', Georgia, serif;
  --font-family-mono: 'JetBrains Mono', 'Fira Code', Consolas, monospace;
  
  /* Font Sizes - Fluid Typography */
  --font-size-xs: clamp(0.75rem, 0.7rem + 0.25vw, 0.875rem);
  --font-size-sm: clamp(0.875rem, 0.8rem + 0.375vw, 1rem);
  --font-size-base: clamp(1rem, 0.925rem + 0.375vw, 1.125rem);
  --font-size-lg: clamp(1.125rem, 1rem + 0.625vw, 1.25rem);
  --font-size-xl: clamp(1.25rem, 1.1rem + 0.75vw, 1.5rem);
  --font-size-2xl: clamp(1.5rem, 1.3rem + 1vw, 2rem);
  --font-size-3xl: clamp(2rem, 1.7rem + 1.5vw, 2.5rem);
  --font-size-4xl: clamp(2.5rem, 2rem + 2.5vw, 3.5rem);
  --font-size-5xl: clamp(3.5rem, 2.5rem + 5vw, 5rem);
  
  /* Font Weights */
  --font-weight-thin: 100;
  --font-weight-light: 300;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
  --font-weight-extrabold: 800;
  --font-weight-black: 900;
  
  /* Line Heights */
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-relaxed: 1.75;
  --line-height-loose: 2;
  
  /* Letter Spacing */
  --letter-spacing-tight: -0.025em;
  --letter-spacing-normal: 0;
  --letter-spacing-wide: 0.025em;
  --letter-spacing-wider: 0.05em;
  --letter-spacing-widest: 0.1em;
  
  /* ===== SPACING SYSTEM ===== */
  --space-0: 0;
  --space-1: 0.25rem;   /* 4px */
  --space-2: 0.5rem;    /* 8px */
  --space-3: 0.75rem;   /* 12px */
  --space-4: 1rem;      /* 16px */
  --space-5: 1.25rem;   /* 20px */
  --space-6: 1.5rem;    /* 24px */
  --space-8: 2rem;      /* 32px */
  --space-10: 2.5rem;   /* 40px */
  --space-12: 3rem;     /* 48px */
  --space-16: 4rem;     /* 64px */
  --space-20: 5rem;     /* 80px */
  --space-24: 6rem;     /* 96px */
  --space-32: 8rem;     /* 128px */
  
  /* ===== BORDER RADIUS ===== */
  --radius-none: 0;
  --radius-sm: 0.125rem;    /* 2px */
  --radius-base: 0.25rem;   /* 4px */
  --radius-md: 0.375rem;    /* 6px */
  --radius-lg: 0.5rem;      /* 8px */
  --radius-xl: 0.75rem;      /* 12px */
  --radius-2xl: 1rem;        /* 16px */
  --radius-3xl: 1.5rem;      /* 24px */
  --radius-full: 9999px;
  
  /* ===== SHADOWS ===== */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-base: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --shadow-inner: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  
  /* Colored Shadows */
  --shadow-primary: 0 10px 15px -3px rgb(20 184 166 / 0.3);
  --shadow-accent: 0 10px 15px -3px rgb(245 158 11 / 0.3);
  --shadow-warm: 0 10px 15px -3px rgb(244 63 94 / 0.3);
  --shadow-cool: 0 10px 15px -3px rgb(168 85 247 / 0.3);
  
  /* ===== Z-INDEX SCALE ===== */
  --z-dropdown: 1000;
  --z-sticky: 1020;
  --z-fixed: 1030;
  --z-modal-backdrop: 1040;
  --z-modal: 1050;
  --z-popover: 1060;
  --z-tooltip: 1070;
  --z-toast: 1080;
  
  /* ===== TRANSITIONS ===== */
  --transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
  --transition-base: 250ms cubic-bezier(0.4, 0, 0.2, 1);
  --transition-slow: 350ms cubic-bezier(0.4, 0, 0.2, 1);
  
  /* ===== BREAKPOINTS ===== */
  --breakpoint-sm: 640px;
  --breakpoint-md: 768px;
  --breakpoint-lg: 1024px;
  --breakpoint-xl: 1280px;
  --breakpoint-2xl: 1536px;
  
  /* ===== CONTAINER MAX WIDTHS ===== */
  --container-sm: 640px;
  --container-md: 768px;
  --container-lg: 1024px;
  --container-xl: 1280px;
  --container-2xl: 1536px;
}
```

### **3. typography.css - Typography System**
```css
/* ===== BASE TYPOGRAPHY ===== */
html {
  font-size: var(--font-size-base);
  line-height: var(--line-height-normal);
}

body {
  font-family: var(--font-family-sans);
  font-weight: var(--font-weight-normal);
  color: var(--color-text-primary);
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* ===== HEADINGS ===== */
h1, h2, h3, h4, h5, h6 {
  font-family: var(--font-family-serif);
  font-weight: var(--font-weight-semibold);
  line-height: var(--line-height-tight);
  color: var(--color-text-primary);
  margin-bottom: var(--space-4);
}

h1 {
  font-size: var(--font-size-4xl);
  font-weight: var(--font-weight-bold);
  letter-spacing: var(--letter-spacing-tight);
}

h2 {
  font-size: var(--font-size-3xl);
  font-weight: var(--font-weight-bold);
}

h3 {
  font-size: var(--font-size-2xl);
  font-weight: var(--font-weight-semibold);
}

h4 {
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-semibold);
}

h5 {
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-medium);
}

h6 {
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
}

/* ===== PARAGRAPH & TEXT ===== */
p {
  margin-bottom: var(--space-4);
  max-width: 65ch; /* Optimal reading width */
}

a {
  color: var(--color-primary-600);
  text-decoration: none;
  transition: color var(--transition-fast);
}

a:hover {
  color: var(--color-primary-700);
  text-decoration: underline;
  text-underline-offset: 2px;
}

a:focus {
  outline: 2px solid var(--color-border-focus);
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}

/* ===== LISTS ===== */
ul, ol {
  margin-bottom: var(--space-4);
  padding-left: var(--space-6);
}

li {
  margin-bottom: var(--space-2);
}

/* ===== TEXT UTILITIES ===== */
.text-xs { font-size: var(--font-size-xs); }
.text-sm { font-size: var(--font-size-sm); }
.text-base { font-size: var(--font-size-base); }
.text-lg { font-size: var(--font-size-lg); }
.text-xl { font-size: var(--font-size-xl); }
.text-2xl { font-size: var(--font-size-2xl); }
.text-3xl { font-size: var(--font-size-3xl); }
.text-4xl { font-size: var(--font-size-4xl); }
.text-5xl { font-size: var(--font-size-5xl); }

.font-thin { font-weight: var(--font-weight-thin); }
.font-light { font-weight: var(--font-weight-light); }
.font-normal { font-weight: var(--font-weight-normal); }
.font-medium { font-weight: var(--font-weight-medium); }
.font-semibold { font-weight: var(--font-weight-semibold); }
.font-bold { font-weight: var(--font-weight-bold); }
.font-extrabold { font-weight: var(--font-weight-extrabold); }
.font-black { font-weight: var(--font-weight-black); }

.leading-tight { line-height: var(--line-height-tight); }
.leading-normal { line-height: var(--line-height-normal); }
.leading-relaxed { line-height: var(--line-height-relaxed); }
.leading-loose { line-height: var(--line-height-loose); }

.tracking-tight { letter-spacing: var(--letter-spacing-tight); }
.tracking-normal { letter-spacing: var(--letter-spacing-normal); }
.tracking-wide { letter-spacing: var(--letter-spacing-wide); }
.tracking-wider { letter-spacing: var(--letter-spacing-wider); }
.tracking-widest { letter-spacing: var(--letter-spacing-widest); }

.text-left { text-align: left; }
.text-center { text-align: center; }
.text-right { text-align: right; }
.text-justify { text-align: justify; }

.uppercase { text-transform: uppercase; }
.lowercase { text-transform: lowercase; }
.capitalize { text-transform: capitalize; }

/* ===== COLOR UTILITIES ===== */
.text-primary { color: var(--color-primary-600); }
.text-secondary { color: var(--color-secondary-600); }
.text-accent { color: var(--color-accent-600); }
.text-warm { color: var(--color-warm-600); }
.text-cool { color: var(--color-cool-600); }
.text-success { color: var(--color-success); }
.text-warning { color: var(--color-warning); }
.text-error { color: var(--color-error); }
.text-info { color: var(--color-info); }

.text-gray-50 { color: var(--color-gray-50); }
.text-gray-100 { color: var(--color-gray-100); }
.text-gray-200 { color: var(--color-gray-200); }
.text-gray-300 { color: var(--color-gray-300); }
.text-gray-400 { color: var(--color-gray-400); }
.text-gray-500 { color: var(--color-gray-500); }
.text-gray-600 { color: var(--color-gray-600); }
.text-gray-700 { color: var(--color-gray-700); }
.text-gray-800 { color: var(--color-gray-800); }
.text-gray-900 { color: var(--color-gray-900); }
```

### **4. layout.css - Layout System**
```css
/* ===== CONTAINER ===== */
.container {
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  padding-left: var(--space-4);
  padding-right: var(--space-4);
}

@media (min-width: 640px) {
  .container { max-width: var(--container-sm); }
}

@media (min-width: 768px) {
  .container { max-width: var(--container-md); }
}

@media (min-width: 1024px) {
  .container { max-width: var(--container-lg); }
}

@media (min-width: 1280px) {
  .container { max-width: var(--container-xl); }
}

@media (min-width: 1536px) {
  .container { max-width: var(--container-2xl); }
}

/* ===== GRID SYSTEM ===== */
.grid {
  display: grid;
  gap: var(--space-4);
}

.grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
.grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
.grid-cols-5 { grid-template-columns: repeat(5, minmax(0, 1fr)); }
.grid-cols-6 { grid-template-columns: repeat(6, minmax(0, 1fr)); }
.grid-cols-7 { grid-template-columns: repeat(7, minmax(0, 1fr)); }
.grid-cols-8 { grid-template-columns: repeat(8, minmax(0, 1fr)); }
.grid-cols-9 { grid-template-columns: repeat(9, minmax(0, 1fr)); }
.grid-cols-10 { grid-template-columns: repeat(10, minmax(0, 1fr)); }
.grid-cols-11 { grid-template-columns: repeat(11, minmax(0, 1fr)); }
.grid-cols-12 { grid-template-columns: repeat(12, minmax(0, 1fr)); }

/* Auto-fit grids */
.grid-auto-fit {
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.grid-auto-fit-300 {
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
}

.grid-auto-fit-400 {
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
}

/* ===== FLEXBOX SYSTEM ===== */
.flex { display: flex; }
.inline-flex { display: inline-flex; }

.flex-row { flex-direction: row; }
.flex-row-reverse { flex-direction: row-reverse; }
.flex-col { flex-direction: column; }
.flex-col-reverse { flex-direction: column-reverse; }

.flex-wrap { flex-wrap: wrap; }
.flex-wrap-reverse { flex-wrap: wrap-reverse; }
.flex-nowrap { flex-wrap: nowrap; }

.items-start { align-items: flex-start; }
.items-end { align-items: flex-end; }
.items-center { align-items: center; }
.items-baseline { align-items: baseline; }
.items-stretch { align-items: stretch; }

.justify-start { justify-content: flex-start; }
.justify-end { justify-content: flex-end; }
.justify-center { justify-content: center; }
.justify-between { justify-content: space-between; }
.justify-around { justify-content: space-around; }
.justify-evenly { justify-content: space-evenly; }

.gap-0 { gap: var(--space-0); }
.gap-1 { gap: var(--space-1); }
.gap-2 { gap: var(--space-2); }
.gap-3 { gap: var(--space-3); }
.gap-4 { gap: var(--space-4); }
.gap-5 { gap: var(--space-5); }
.gap-6 { gap: var(--space-6); }
.gap-8 { gap: var(--space-8); }
.gap-10 { gap: var(--space-10); }
.gap-12 { gap: var(--space-12); }
.gap-16 { gap: var(--space-16); }

/* ===== SPACING UTILITIES ===== */
.p-0 { padding: var(--space-0); }
.p-1 { padding: var(--space-1); }
.p-2 { padding: var(--space-2); }
.p-3 { padding: var(--space-3); }
.p-4 { padding: var(--space-4); }
.p-5 { padding: var(--space-5); }
.p-6 { padding: var(--space-6); }
.p-8 { padding: var(--space-8); }
.p-10 { padding: var(--space-10); }
.p-12 { padding: var(--space-12); }
.p-16 { padding: var(--space-16); }

.px-0 { padding-left: var(--space-0); padding-right: var(--space-0); }
.px-1 { padding-left: var(--space-1); padding-right: var(--space-1); }
.px-2 { padding-left: var(--space-2); padding-right: var(--space-2); }
.px-3 { padding-left: var(--space-3); padding-right: var(--space-3); }
.px-4 { padding-left: var(--space-4); padding-right: var(--space-4); }
.px-5 { padding-left: var(--space-5); padding-right: var(--space-5); }
.px-6 { padding-left: var(--space-6); padding-right: var(--space-6); }
.px-8 { padding-left: var(--space-8); padding-right: var(--space-8); }

.py-0 { padding-top: var(--space-0); padding-bottom: var(--space-0); }
.py-1 { padding-top: var(--space-1); padding-bottom: var(--space-1); }
.py-2 { padding-top: var(--space-2); padding-bottom: var(--space-2); }
.py-3 { padding-top: var(--space-3); padding-bottom: var(--space-3); }
.py-4 { padding-top: var(--space-4); padding-bottom: var(--space-4); }
.py-5 { padding-top: var(--space-5); padding-bottom: var(--space-5); }
.py-6 { padding-top: var(--space-6); padding-bottom: var(--space-6); }
.py-8 { padding-top: var(--space-8); padding-bottom: var(--space-8); }

.m-0 { margin: var(--space-0); }
.m-1 { margin: var(--space-1); }
.m-2 { margin: var(--space-2); }
.m-3 { margin: var(--space-3); }
.m-4 { margin: var(--space-4); }
.m-5 { margin: var(--space-5); }
.m-6 { margin: var(--space-6); }
.m-8 { margin: var(--space-8); }
.m-10 { margin: var(--space-10); }
.m-12 { margin: var(--space-12); }
.m-16 { margin: var(--space-16); }

.mx-auto { margin-left: auto; margin-right: auto; }
.ml-auto { margin-left: auto; }
.mr-auto { margin-right: auto; }
.mt-auto { margin-top: auto; }
.mb-auto { margin-bottom: auto; }

/* ===== SECTION LAYOUT ===== */
.section {
  padding-top: var(--space-16);
  padding-bottom: var(--space-16);
}

.section-sm {
  padding-top: var(--space-12);
  padding-bottom: var(--space-12);
}

.section-lg {
  padding-top: var(--space-20);
  padding-bottom: var(--space-20);
}

.section-xl {
  padding-top: var(--space-24);
  padding-bottom: var(--space-24);
}

/* ===== VISIBILITY ===== */
.block { display: block; }
.inline-block { display: inline-block; }
.inline { display: inline; }
.hidden { display: none; }

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

---

## **COMPLETE COMPONENT SPECIFICATIONS**

### **1. BUTTON COMPONENTS**
```css
/* ===== BASE BUTTON ===== */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-6);
  font-family: var(--font-family-sans);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  line-height: 1;
  text-decoration: none;
  border: 2px solid transparent;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all var(--transition-base);
  user-select: none;
  white-space: nowrap;
}

.btn:focus {
  outline: 2px solid var(--color-border-focus);
  outline-offset: 2px;
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}

/* ===== BUTTON VARIANTS ===== */
.btn-primary {
  background-color: var(--color-primary-600);
  color: white;
  border-color: var(--color-primary-600);
  box-shadow: var(--shadow-md);
}

.btn-primary:hover:not(:disabled) {
  background-color: var(--color-primary-700);
  border-color: var(--color-primary-700);
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.btn-primary:active:not(:disabled) {
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.btn-secondary {
  background-color: transparent;
  color: var(--color-primary-600);
  border-color: var(--color-primary-600);
}

.btn-secondary:hover:not(:disabled) {
  background-color: var(--color-primary-600);
  color: white;
  transform: translateY(-2px);
  box-shadow: var(--shadow-primary);
}

.btn-accent {
  background-color: var(--color-accent-500);
  color: white;
  border-color: var(--color-accent-500);
  box-shadow: var(--shadow-md);
}

.btn-accent:hover:not(:disabled) {
  background-color: var(--color-accent-600);
  border-color: var(--color-accent-600);
  transform: translateY(-2px);
  box-shadow: var(--shadow-accent);
}

.btn-warm {
  background-color: var(--color-warm-500);
  color: white;
  border-color: var(--color-warm-500);
  box-shadow: var(--shadow-md);
}

.btn-warm:hover:not(:disabled) {
  background-color: var(--color-warm-600);
  border-color: var(--color-warm-600);
  transform: translateY(-2px);
  box-shadow: var(--shadow-warm);
}

.btn-outline {
  background-color: transparent;
  color: var(--color-text-primary);
  border-color: var(--color-border-primary);
}

.btn-outline:hover:not(:disabled) {
  background-color: var(--color-gray-50);
  border-color: var(--color-gray-300);
}

.btn-ghost {
  background-color: transparent;
  color: var(--color-text-primary);
  border-color: transparent;
}

.btn-ghost:hover:not(:disabled) {
  background-color: var(--color-gray-100);
}

/* ===== BUTTON SIZES ===== */
.btn-sm {
  padding: var(--space-2) var(--space-4);
  font-size: var(--font-size-sm);
}

.btn-lg {
  padding: var(--space-4) var(--space-8);
  font-size: var(--font-size-lg);
}

.btn-xl {
  padding: var(--space-5) var(--space-10);
  font-size: var(--font-size-xl);
}

/* ===== BUTTON GROUP ===== */
.btn-group {
  display: inline-flex;
  border-radius: var(--radius-full);
  overflow: hidden;
  box-shadow: var(--shadow-sm);
}

.btn-group .btn {
  border-radius: 0;
  box-shadow: none;
}

.btn-group .btn:first-child {
  border-top-left-radius: var(--radius-full);
  border-bottom-left-radius: var(--radius-full);
}

.btn-group .btn:last-child {
  border-top-right-radius: var(--radius-full);
  border-bottom-right-radius: var(--radius-full);
}

.btn-group .btn:not(:first-child) {
  border-left: 1px solid var(--color-border-primary);
}
```

### **2. CARD COMPONENTS**
```css
/* ===== BASE CARD ===== */
.card {
  background-color: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-sm);
  overflow: hidden;
  transition: all var(--transition-base);
}

.card:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-4px);
}

/* ===== CARD VARIANTS ===== */
.card-interactive {
  cursor: pointer;
}

.card-interactive:hover {
  box-shadow: var(--shadow-lg);
  transform: translateY(-8px);
}

.card-featured {
  border-color: var(--color-primary-200);
  box-shadow: var(--shadow-primary);
}

.card-featured:hover {
  box-shadow: var(--shadow-lg), var(--shadow-primary);
  transform: translateY(-12px);
}

.card-elevated {
  box-shadow: var(--shadow-md);
}

.card-elevated:hover {
  box-shadow: var(--shadow-xl);
  transform: translateY(-6px);
}

/* ===== CARD SECTIONS ===== */
.card-header {
  padding: var(--space-6);
  border-bottom: 1px solid var(--color-border-primary);
}

.card-body {
  padding: var(--space-6);
}

.card-footer {
  padding: var(--space-6);
  border-top: 1px solid var(--color-border-primary);
  background-color: var(--color-bg-secondary);
}

/* ===== SERVICE CARD ===== */
.service-card {
  position: relative;
  background: linear-gradient(135deg, var(--color-bg-primary) 0%, var(--color-gray-50) 100%);
  border: 1px solid var(--color-gray-200);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  text-align: center;
  transition: all var(--transition-slow);
  overflow: hidden;
}

.service-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--color-primary-500), var(--color-accent-500));
  transform: scaleX(0);
  transition: transform var(--transition-base);
}

.service-card:hover::before {
  transform: scaleX(1);
}

.service-card:hover {
  transform: translateY(-12px);
  box-shadow: var(--shadow-xl), var(--shadow-primary);
  border-color: var(--color-primary-300);
}

.service-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto var(--space-4);
  background: linear-gradient(135deg, var(--color-primary-500), var(--color-primary-600));
  border-radius: var(--radius-2xl);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  color: white;
  box-shadow: var(--shadow-md);
}

.service-title {
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-semibold);
  color: var(--color-text-primary);
  margin-bottom: var(--space-3);
}

.service-description {
  color: var(--color-text-secondary);
  line-height: var(--line-height-relaxed);
  margin-bottom: var(--space-4);
}

.service-tags {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  justify-content: center;
}

.service-tag {
  background-color: var(--color-primary-100);
  color: var(--color-primary-700);
  padding: var(--space-1) var(--space-3);
  border-radius: var(--radius-full);
  font-size: var(--font-size-xs);
  font-weight: var(--font-weight-medium);
  text-transform: uppercase;
  letter-spacing: var(--letter-spacing-wide);
}
```

### **3. NAVIGATION COMPONENT**
```css
/* ===== NAVIGATION BAR ===== */
.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: var(--z-sticky);
  background-color: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--color-border-primary);
  transition: all var(--transition-base);
}

.navbar-scrolled {
  background-color: rgba(255, 255, 255, 0.98);
  box-shadow: var(--shadow-md);
}

.navbar-container {
  max-width: var(--container-xl);
  margin: 0 auto;
  padding: 0 var(--space-4);
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 80px;
}

/* ===== LOGO ===== */
.navbar-logo {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-bold);
  font-family: var(--font-family-serif);
  color: var(--color-text-primary);
  text-decoration: none;
  transition: color var(--transition-fast);
}

.navbar-logo:hover {
  color: var(--color-primary-600);
}

.navbar-logo-icon {
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, var(--color-primary-500), var(--color-primary-600));
  border-radius: var(--radius-lg);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.5rem;
}

/* ===== NAVIGATION MENU ===== */
.navbar-menu {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  list-style: none;
  margin: 0;
  padding: 0;
}

.navbar-link {
  color: var(--color-text-secondary);
  font-weight: var(--font-weight-medium);
  text-decoration: none;
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-lg);
  transition: all var(--transition-fast);
  position: relative;
}

.navbar-link:hover {
  color: var(--color-primary-600);
  background-color: var(--color-primary-50);
}

.navbar-link.active {
  color: var(--color-primary-600);
  background-color: var(--color-primary-100);
}

/* ===== MOBILE MENU TOGGLE ===== */
.navbar-toggle {
  display: none;
  flex-direction: column;
  gap: var(--space-1);
  background: none;
  border: none;
  cursor: pointer;
  padding: var(--space-2);
}

.navbar-toggle span {
  width: 24px;
  height: 2px;
  background-color: var(--color-text-primary);
  transition: all var(--transition-base);
}

.navbar-toggle.active span:nth-child(1) {
  transform: rotate(45deg) translate(5px, 5px);
}

.navbar-toggle.active span:nth-child(2) {
  opacity: 0;
}

.navbar-toggle.active span:nth-child(3) {
  transform: rotate(-45deg) translate(7px, -6px);
}

/* ===== MOBILE MENU ===== */
.navbar-mobile {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background-color: white;
  border-top: 1px solid var(--color-border-primary);
  box-shadow: var(--shadow-lg);
  max-height: 0;
  overflow: hidden;
  transition: max-height var(--transition-base);
}

.navbar-mobile.active {
  max-height: 500px;
}

.navbar-mobile-menu {
  list-style: none;
  margin: 0;
  padding: var(--space-4);
}

.navbar-mobile-link {
  display: block;
  color: var(--color-text-secondary);
  font-weight: var(--font-weight-medium);
  text-decoration: none;
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-lg);
  transition: all var(--transition-fast);
}

.navbar-mobile-link:hover {
  color: var(--color-primary-600);
  background-color: var(--color-primary-50);
}

/* ===== RESPONSIVE NAVIGATION ===== */
@media (max-width: 1024px) {
  .navbar-menu {
    display: none;
  }
  
  .navbar-toggle {
    display: flex;
  }
  
  .navbar-mobile {
    display: block;
  }
}
```

---

## **COMPLETE JAVASCRIPT ARCHITECTURE**

### **1. main.js - Main JavaScript File**
```javascript
/**
 * Sambasiva Psychology Website - Main JavaScript
 * Handles all interactive functionality and animations
 */

// ===== CONFIGURATION =====
const CONFIG = {
  // Animation settings
  animation: {
    duration: 600,
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    offset: 100,
    threshold: 0.1
  },
  
  // Form settings
  form: {
    debounceTime: 300,
    validationTimeout: 5000
  },
  
  // Navigation settings
  nav: {
    scrollOffset: 80,
    mobileBreakpoint: 1024
  },
  
  // Performance settings
  performance: {
    enableAnimations: true,
    enableParallax: true,
    enableCounters: true
  }
};

// ===== UTILITY FUNCTIONS =====
const Utils = {
  /**
   * Debounce function to limit function calls
   */
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Throttle function to limit function calls
   */
  throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  /**
   * Check if element is in viewport
   */
  isInViewport(element, threshold = 0.1) {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;

    const vertInView = (rect.top <= windowHeight * (1 - threshold)) && ((rect.top + rect.height) >= windowHeight * threshold);
    const horInView = (rect.left <= windowWidth * (1 - threshold)) && ((rect.left + rect.width) >= windowWidth * threshold);

    return (vertInView && horInView);
  },

  /**
   * Smooth scroll to element
   */
  scrollToElement(element, offset = 0) {
    const targetPosition = element.offsetTop - offset;
    window.scrollTo({
      top: targetPosition,
      behavior: 'smooth'
    });
  },

  /**
   * Get element offset from top of document
   */
  getElementOffset(element) {
    let offsetTop = 0;
    while (element) {
      offsetTop += element.offsetTop;
      element = element.offsetParent;
    }
    return offsetTop;
  },

  /**
   * Animate number counter
   */
  animateCounter(element, target, duration = 2000, suffix = '') {
    const start = 0;
    const startTime = performance.now();
    
    function updateCounter(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const current = Math.floor(easeOutQuart * target);
      
      element.textContent = current.toLocaleString() + suffix;
      
      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      }
    }
    
    requestAnimationFrame(updateCounter);
  },

  /**
   * Check if user prefers reduced motion
   */
  prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  },

  /**
   * Check if device is mobile
   */
  isMobile() {
    return window.innerWidth <= CONFIG.nav.mobileBreakpoint;
  },

  /**
   * Get CSS custom property value
   */
  getCSSVariable(property) {
    return getComputedStyle(document.documentElement)
      .getPropertyValue(property).trim();
  },

  /**
   * Set CSS custom property
   */
  setCSSVariable(property, value) {
    document.documentElement
      .style.setProperty(property, value);
  }
};

// ===== NAVIGATION MODULE =====
const Navigation = {
  elements: {
    navbar: null,
    toggle: null,
    mobileMenu: null,
    links: null
  },

  state: {
    isScrolled: false,
    isMobileMenuOpen: false
  },

  init() {
    this.cacheElements();
    this.bindEvents();
    this.updateScrollState();
  },

  cacheElements() {
    this.elements.navbar = document.querySelector('.navbar');
    this.elements.toggle = document.querySelector('.navbar-toggle');
    this.elements.mobileMenu = document.querySelector('.navbar-mobile');
    this.elements.links = document.querySelectorAll('.navbar-link, .navbar-mobile-link');
  },

  bindEvents() {
    // Scroll events
    window.addEventListener('scroll', Utils.throttle(() => {
      this.updateScrollState();
    }, 16));

    // Mobile menu toggle
    if (this.elements.toggle) {
      this.elements.toggle.addEventListener('click', () => {
        this.toggleMobileMenu();
      });
    }

    // Mobile menu links
    this.elements.links.forEach(link => {
      link.addEventListener('click', (e) => {
        if (link.getAttribute('href').startsWith('#')) {
          e.preventDefault();
          this.handleAnchorLink(link);
        }
      });
    });

    // Close mobile menu on escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.state.isMobileMenuOpen) {
        this.closeMobileMenu();
      }
    });

    // Close mobile menu on outside click
    document.addEventListener('click', (e) => {
      if (this.state.isMobileMenuOpen && 
          !this.elements.navbar.contains(e.target)) {
        this.closeMobileMenu();
      }
    });
  },

  updateScrollState() {
    const scrolled = window.scrollY > 50;
    
    if (scrolled !== this.state.isScrolled) {
      this.state.isScrolled = scrolled;
      this.elements.navbar.classList.toggle('navbar-scrolled', scrolled);
    }
  },

  toggleMobileMenu() {
    this.state.isMobileMenuOpen = !this.state.isMobileMenuOpen;
    this.elements.toggle.classList.toggle('active', this.state.isMobileMenuOpen);
    this.elements.mobileMenu.classList.toggle('active', this.state.isMobileMenuOpen);
    
    // Prevent body scroll when menu is open
    document.body.style.overflow = this.state.isMobileMenuOpen ? 'hidden' : '';
  },

  closeMobileMenu() {
    this.state.isMobileMenuOpen = false;
    this.elements.toggle.classList.remove('active');
    this.elements.mobileMenu.classList.remove('active');
    document.body.style.overflow = '';
  },

  handleAnchorLink(link) {
    const targetId = link.getAttribute('href').substring(1);
    const targetElement = document.getElementById(targetId);
    
    if (targetElement) {
      Utils.scrollToElement(targetElement, CONFIG.nav.scrollOffset);
      this.closeMobileMenu();
      
      // Update active state
      this.elements.links.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    }
  }
};

// ===== ANIMATION MODULE =====
const Animations = {
  elements: {
    animatedElements: null,
    counters: null
  },

  observers: {
    intersection: null,
    counter: null
  },

  init() {
    if (!CONFIG.performance.enableAnimations || Utils.prefersReducedMotion()) {
      return;
    }

    this.cacheElements();
    this.setupIntersectionObserver();
    this.setupCounterObserver();
    this.bindEvents();
  },

  cacheElements() {
    this.elements.animatedElements = document.querySelectorAll('[data-animate]');
    this.elements.counters = document.querySelectorAll('[data-counter]');
  },

  setupIntersectionObserver() {
    this.observers.intersection = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.animateElement(entry.target);
          this.observers.intersection.unobserve(entry.target);
        }
      });
    }, {
      threshold: CONFIG.animation.threshold,
      rootMargin: `${CONFIG.animation.offset}px`
    });

    this.elements.animatedElements.forEach(element => {
      this.observers.intersection.observe(element);
    });
  },

  setupCounterObserver() {
    if (!CONFIG.performance.enableCounters) return;

    this.observers.counter = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.animateCounter(entry.target);
          this.observers.counter.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.5
    });

    this.elements.counters.forEach(element => {
      this.observers.counter.observe(element);
    });
  },

  animateElement(element) {
    const animationType = element.dataset.animate;
    const delay = element.dataset.delay || 0;

    setTimeout(() => {
      element.classList.add('animate-in');
      
      // Handle specific animation types
      switch (animationType) {
        case 'fade-in-up':
          this.fadeInUp(element);
          break;
        case 'fade-in-left':
          this.fadeInLeft(element);
          break;
        case 'fade-in-right':
          this.fadeInRight(element);
          break;
        case 'scale-in':
          this.scaleIn(element);
          break;
        default:
          this.fadeIn(element);
      }
    }, delay);
  },

  animateCounter(element) {
    const target = parseInt(element.dataset.counter);
    const suffix = element.dataset.suffix || '';
    const duration = element.dataset.duration || 2000;

    Utils.animateCounter(element, target, duration, suffix);
  },

  // Animation functions
  fadeIn(element) {
    element.style.opacity = '0';
    element.style.transform = 'translateY(20px)';
    
    requestAnimationFrame(() => {
      element.style.transition = `opacity ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}, transform ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}`;
      element.style.opacity = '1';
      element.style.transform = 'translateY(0)';
    });
  },

  fadeInUp(element) {
    element.style.opacity = '0';
    element.style.transform = 'translateY(40px)';
    
    requestAnimationFrame(() => {
      element.style.transition = `opacity ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}, transform ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}`;
      element.style.opacity = '1';
      element.style.transform = 'translateY(0)';
    });
  },

  fadeInLeft(element) {
    element.style.opacity = '0';
    element.style.transform = 'translateX(-40px)';
    
    requestAnimationFrame(() => {
      element.style.transition = `opacity ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}, transform ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}`;
      element.style.opacity = '1';
      element.style.transform = 'translateX(0)';
    });
  },

  fadeInRight(element) {
    element.style.opacity = '0';
    element.style.transform = 'translateX(40px)';
    
    requestAnimationFrame(() => {
      element.style.transition = `opacity ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}, transform ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}`;
      element.style.opacity = '1';
      element.style.transform = 'translateX(0)';
    });
  },

  scaleIn(element) {
    element.style.opacity = '0';
    element.style.transform = 'scale(0.8)';
    
    requestAnimationFrame(() => {
      element.style.transition = `opacity ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}, transform ${CONFIG.animation.duration}ms ${CONFIG.animation.easing}`;
      element.style.opacity = '1';
      element.style.transform = 'scale(1)';
    });
  },

  bindEvents() {
    // Handle window resize for performance optimization
    window.addEventListener('resize', Utils.throttle(() => {
      this.handleResize();
    }, 250));
  },

  handleResize() {
    // Re-initialize observers if needed
    if (Utils.isMobile() !== this.wasMobile) {
      this.wasMobile = Utils.isMobile();
      // Re-setup observers for mobile/desktop differences
    }
  }
};

// ===== FORM MODULE =====
const Forms = {
  elements: {
    forms: null,
    inputs: null,
    textareas: null,
    selects: null
  },

  validators: {
    required: (value) => value.trim().length > 0,
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    phone: (value) => /^[\d\s\-\+\(\)]+$/.test(value) && value.replace(/\D/g, '').length >= 10,
    minLength: (value, min) => value.length >= min,
    maxLength: (value, max) => value.length <= max
  },

  init() {
    this.cacheElements();
    this.bindEvents();
  },

  cacheElements() {
    this.elements.forms = document.querySelectorAll('form');
    this.elements.inputs = document.querySelectorAll('input, textarea, select');
  },

  bindEvents() {
    // Form submission
    this.elements.forms.forEach(form => {
      form.addEventListener('submit', (e) => this.handleSubmit(e));
    });

    // Input validation
    this.elements.inputs.forEach(input => {
      input.addEventListener('blur', () => this.validateField(input));
      input.addEventListener('input', Utils.debounce(() => {
        this.clearFieldError(input);
      }, CONFIG.form.debounceTime));
    });
  },

  handleSubmit(event) {
    event.preventDefault();
    const form = event.target;
    
    if (this.validateForm(form)) {
      this.submitForm(form);
    }
  },

  validateForm(form) {
    const inputs = form.querySelectorAll('input, textarea, select');
    let isValid = true;

    inputs.forEach(input => {
      if (!this.validateField(input)) {
        isValid = false;
      }
    });

    return isValid;
  },

  validateField(input) {
    const value = input.value.trim();
    const rules = JSON.parse(input.dataset.validation || '{}');
    let isValid = true;
    let errorMessage = '';

    // Check required
    if (rules.required && !this.validators.required(value)) {
      isValid = false;
      errorMessage = 'This field is required';
    }

    // Check email
    if (isValid && rules.email && !this.validators.email(value)) {
      isValid = false;
      errorMessage = 'Please enter a valid email address';
    }

    // Check phone
    if (isValid && rules.phone && !this.validators.phone(value)) {
      isValid = false;
      errorMessage = 'Please enter a valid phone number';
    }

    // Check min length
    if (isValid && rules.minLength && !this.validators.minLength(value, rules.minLength)) {
      isValid = false;
      errorMessage = `Minimum ${rules.minLength} characters required`;
    }

    // Check max length
    if (isValid && rules.maxLength && !this.validators.maxLength(value, rules.maxLength)) {
      isValid = false;
      errorMessage = `Maximum ${rules.maxLength} characters allowed`;
    }

    if (isValid) {
      this.clearFieldError(input);
    } else {
      this.showFieldError(input, errorMessage);
    }

    return isValid;
  },

  showFieldError(input, message) {
    this.clearFieldError(input);
    
    input.classList.add('error');
    
    const errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    
    input.parentNode.appendChild(errorElement);
  },

  clearFieldError(input) {
    input.classList.remove('error');
    
    const errorElement = input.parentNode.querySelector('.field-error');
    if (errorElement) {
      errorElement.remove();
    }
  },

  submitForm(form) {
    const formData = new FormData(form);
    const submitButton = form.querySelector('button[type="submit"]');
    
    // Show loading state
    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Submitting...';
    }

    // Simulate form submission
    setTimeout(() => {
      this.handleFormSuccess(form, formData);
    }, 2000);
  },

  handleFormSuccess(form, formData) {
    const submitButton = form.querySelector('button[type="submit"]');
    
    // Show success message
    this.showSuccessMessage(form);
    
    // Reset form
    form.reset();
    
    // Reset button
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = 'Submit';
    }

    // Track form submission
    this.trackFormSubmission(form);
  },

  showSuccessMessage(form) {
    const message = document.createElement('div');
    message.className = 'form-success';
    message.textContent = 'Thank you! Your message has been sent successfully.';
    
    form.appendChild(message);
    
    setTimeout(() => {
      message.remove();
    }, 5000);
  },

  trackFormSubmission(form) {
    // Google Analytics or other tracking
    if (typeof gtag !== 'undefined') {
      gtag('event', 'form_submit', {
        form_name: form.name || 'contact_form'
      });
    }
  }
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
  // Check for reduced motion preference
  if (Utils.prefersReducedMotion()) {
    CONFIG.performance.enableAnimations = false;
    CONFIG.performance.enableParallax = false;
  }

  // Initialize modules
  Navigation.init();
  Animations.init();
  Forms.init();

  // Add loaded class to body
  document.body.classList.add('loaded');
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    // Pause animations when page is not visible
    CONFIG.performance.enableAnimations = false;
  } else {
    // Resume animations when page is visible
    CONFIG.performance.enableAnimations = !Utils.prefersReducedMotion();
  }
});

// Export for external use if needed
window.SambasivaWebsite = {
  Utils,
  Navigation,
  Animations,
  Forms,
  CONFIG
};
```

---

## **COMPLETE HTML TEMPLATES**

### **1. Base Template Structure**
```html
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <!-- Meta Tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="robots" content="index, follow">
  
  <!-- SEO Meta Tags -->
  <title>[PAGE_TITLE] | Sambasiva - Psychologist in Vizag</title>
  <meta name="description" content="[PAGE_DESCRIPTION]">
  <meta name="keywords" content="[PAGE_KEYWORDS]">
  <meta name="author" content="Dr. Sambasiva">
  
  <!-- Open Graph Meta Tags -->
  <meta property="og:title" content="[OG_TITLE]">
  <meta property="og:description" content="[OG_DESCRIPTION]">
  <meta property="og:type" content="website">
  <meta property="og:url" content="[PAGE_URL]">
  <meta property="og:image" content="[OG_IMAGE]">
  <meta property="og:site_name" content="Dr. Sambasiva">
  
  <!-- Twitter Card Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="[TWITTER_TITLE]">
  <meta name="twitter:description" content="[TWITTER_DESCRIPTION]">
  <meta name="twitter:image" content="[TWITTER_IMAGE]">
  
  <!-- Canonical URL -->
  <link rel="canonical" href="[CANONICAL_URL]">
  
  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="/assets/images/favicon.ico">
  <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
  <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
  
  <!-- Preconnect to External Domains -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="preconnect" href="https://unpkg.com">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  
  <!-- CSS Files -->
  <link rel="stylesheet" href="/assets/css/main.css">
  
  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "[SCHEMA_TYPE]",
    "name": "[SCHEMA_NAME]",
    "description": "[SCHEMA_DESCRIPTION]",
    "url": "[SCHEMA_URL]",
    "telephone": "+91-98765-43210",
    "email": "hello@sambasiva.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "MVP Colony",
      "addressLocality": "Visakhapatnam",
      "addressRegion": "Andhra Pradesh",
      "postalCode": "530017",
      "addressCountry": "IN"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "17.7449",
      "longitude": "83.2509"
    },
    "priceRange": "$$",
    "openingHours": "Mo-Su 09:00-21:00"
  }
  </script>
</head>
<body>
  <!-- Skip to main content for accessibility -->
  <a href="#main-content" class="sr-only">Skip to main content</a>
  
  <!-- Navigation -->
  <nav class="navbar" role="navigation" aria-label="Main navigation">
    <div class="navbar-container">
      <!-- Logo -->
      <a href="/" class="navbar-logo" aria-label="Sambasiva Home">
        <div class="navbar-logo-icon">
          <i data-lucide="brain"></i>
        </div>
        <span>Dr. Sambasiva</span>
      </a>
      
      <!-- Desktop Menu -->
      <ul class="navbar-menu" role="menubar">
        <li role="none">
          <a href="/" class="navbar-link active" role="menuitem">Home</a>
        </li>
        <li role="none">
          <a href="/about.html" class="navbar-link" role="menuitem">About</a>
        </li>
        <li role="none">
          <a href="/services.html" class="navbar-link" role="menuitem">Services</a>
        </li>
        <li role="none">
          <a href="/training.html" class="navbar-link" role="menuitem">Training</a>
        </li>
        <li role="none">
          <a href="/blog.html" class="navbar-link" role="menuitem">Blog</a>
        </li>
        <li role="none">
          <a href="/contact.html" class="navbar-link" role="menuitem">Contact</a>
        </li>
      </ul>
      
      <!-- CTA Button -->
      <div class="navbar-cta">
        <a href="/contact.html" class="btn btn-primary">
          <i data-lucide="calendar"></i>
          <span>Book Session</span>
        </a>
      </div>
      
      <!-- Mobile Menu Toggle -->
      <button class="navbar-toggle" aria-label="Toggle mobile menu" aria-expanded="false">
        <span></span>
        <span></span>
        <span></span>
      </button>
    </div>
    
    <!-- Mobile Menu -->
    <div class="navbar-mobile" role="navigation" aria-label="Mobile navigation">
      <ul class="navbar-mobile-menu">
        <li>
          <a href="/" class="navbar-mobile-link">Home</a>
        </li>
        <li>
          <a href="/about.html" class="navbar-mobile-link">About</a>
        </li>
        <li>
          <a href="/services.html" class="navbar-mobile-link">Services</a>
        </li>
        <li>
          <a href="/training.html" class="navbar-mobile-link">Training</a>
        </li>
        <li>
          <a href="/blog.html" class="navbar-mobile-link">Blog</a>
        </li>
        <li>
          <a href="/contact.html" class="navbar-mobile-link">Contact</a>
        </li>
        <li>
          <a href="/contact.html" class="btn btn-primary w-full">Book Session</a>
        </li>
      </ul>
    </div>
  </nav>
  
  <!-- Main Content -->
  <main id="main-content" role="main">
    [PAGE_CONTENT]
  </main>
  
  <!-- Footer -->
  <footer class="footer" role="contentinfo">
    <div class="container">
      <div class="footer-content">
        <!-- Footer sections -->
      </div>
      <div class="footer-bottom">
        <p>&copy; [CURRENT_YEAR] Dr. Sambasiva. All rights reserved.</p>
        <div class="footer-links">
          <a href="/privacy.html">Privacy Policy</a>
          <a href="/terms.html">Terms of Use</a>
          <a href="/sitemap.html">Sitemap</a>
        </div>
      </div>
    </div>
  </footer>
  
  <!-- WhatsApp Float Button -->
  <a href="https://wa.me/919876543210?text=Hi%20Sambasiva%2C%20I'd%20like%20to%20book%20a%20consultation" 
     class="whatsapp-float" 
     target="_blank" 
     rel="noopener noreferrer"
     aria-label="Chat on WhatsApp">
    <i data-lucide="message-circle"></i>
    <span class="whatsapp-tooltip">Chat on WhatsApp</span>
  </a>
  
  <!-- JavaScript -->
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
  <script src="/assets/js/main.js"></script>
  
  <!-- Initialize Lucide icons -->
  <script>
    lucide.createIcons();
  </script>
</body>
</html>
```

---

## **PERFORMANCE OPTIMIZATION SPECIFICATIONS**

### **1. Critical CSS**
```css
/* Inline critical CSS for above-the-fold content */
.critical-css {
  /* Only essential styles for immediate rendering */
}
```

### **2. Image Optimization**
```html
<!-- Optimized image loading -->
<img 
  src="[IMAGE_PATH].webp"
  srcset="
    [IMAGE_PATH]-small.webp 400w,
    [IMAGE_PATH]-medium.webp 800w,
    [IMAGE_PATH]-large.webp 1200w
  "
  sizes="(max-width: 400px) 400px, (max-width: 800px) 800px, 1200px"
  alt="[ALT_TEXT]"
  loading="lazy"
  width="1200"
  height="800"
  decoding="async"
>
```

### **3. Font Loading Strategy**
```html
<!-- Preload critical fonts -->
<link rel="preload" href="/assets/fonts/inter-regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/assets/fonts/playfair-display-bold.woff2" as="font" type="font/woff2" crossorigin>
```

---

## **SEO IMPLEMENTATION SPECIFICATIONS**

### **1. Meta Tags Template**
```html
<!-- Primary Keywords: psychologist in Vizag, counseling in Vizag -->
<title>Best Psychologist in Vizag | Counseling & Therapy Services</title>
<meta name="description" content="Looking for a psychologist in Vizag? Expert counseling in Visakhapatnam for anxiety, stress, relationships. 6.5+ years experience. Book now.">
<meta name="keywords" content="psychologist in Vizag, counseling in Vizag, best psychologist in Visakhapatnam, therapy for anxiety in Vizag, relationship counselor Vizag, clinical psychologist Vizag, mental health counseling Vizag, online counseling in Vizag, stress management therapy Vizag, depression treatment Vizag, psychologist near me">
```

### **2. Structured Data Templates**
```json
{
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "name": "Dr. Sambasiva - Best Psychologist in Vizag",
  "description": "Professional psychologist in Vizag providing expert counseling and therapy services",
  "url": "https://sambasiva.com",
  "telephone": "+91-98765-43210",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "MVP Colony",
    "addressLocality": "Visakhapatnam",
    "addressRegion": "Andhra Pradesh",
    "postalCode": "530017",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "17.7449",
    "longitude": "83.2509"
  },
  "openingHours": "Mo-Su 09:00-21:00",
  "priceRange": "$$",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "reviewCount": "150"
  }
}
```

---

## **TESTING & QUALITY ASSURANCE**

### **1. Browser Testing Matrix**
- **Chrome**: Latest version
- **Firefox**: Latest version
- **Safari**: Latest version
- **Edge**: Latest version
- **Mobile Safari**: iOS 12+
- **Chrome Mobile**: Android 8+

### **2. Performance Testing**
- **PageSpeed Insights**: 90+ score
- **Lighthouse**: 90+ overall score
- **GTmetrix**: A grade
- **WebPageTest**: Load time <3s

### **3. Accessibility Testing**
- **WCAG 2.1 AA**: Full compliance
- **Screen readers**: NVDA, JAWS, VoiceOver
- **Keyboard navigation**: Full functionality
- **Color contrast**: 4.5:1 minimum ratio

---

This comprehensive specification provides every technical detail needed for clean, issue-free development of the Sambasiva psychology website. All components are designed with performance, accessibility, and SEO in mind.
